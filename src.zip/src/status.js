export default function Status() {
  return (
    <>
      <Nav></Nav>
    </>
  );
}
