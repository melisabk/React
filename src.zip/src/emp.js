
  /*import React from "react";
    import User from "./user";
    import userphoto from "./smiling-business-woman.jpg";
    export default function row({ src }) {
        return (
            <>
                <button>
                    <img src={src} alt="empphoto" />
                </button>
                <div>
                    <User user={userData} src={userphoto} />
                    <User user={userData} src={userphoto} />
                    <User user={userData} src={userphoto} />
                    <User user={userData} src={userphoto} />
                </div>
            </>
        );
    }
*/

